//
//  PageThree.swift
//  Demo
//
//  Created by Kevin Izadpanah on 2/11/17.
//  Copyright © 2017 Kevin Izadpanah. All rights reserved.
//

import Foundation

class PageThree:UIViewController{

    @IBOutlet weak var Open: UIBarButtonItem!
    
    override func viewDidLoad() {
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        Open.target = self.revealViewController()
        Open.action = Selector("revealToggle:")
        
    }
    

}

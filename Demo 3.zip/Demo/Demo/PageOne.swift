//
//  PageOne.swift
//  Demo
//
//  Created by Kevin Izadpanah on 2/11/17.
//  Copyright © 2017 Kevin Izadpanah. All rights reserved.
//
/*
  If your app goes in the App Store, you’ll have to attach this disclaimer to your app’s description: 
   “Continued use of GPS running in the background can dramatically decrease battery life.”

*/
import Foundation
import MapKit
import HealthKit
import CoreLocation

              //parent          //protocol       //protocol
class PageOne:UIViewController,MKMapViewDelegate,CLLocationManagerDelegate{
    
    var locationManager: CLLocationManager!
    var previousLocation: CLLocation!

    //the Menu button that allows you to go back to the backtable view controller
    @IBOutlet weak var Open: UIBarButtonItem!

    //the map view that allows you to see the map displayed
    @IBOutlet weak var map: MKMapView!
 

    override func viewDidLoad() {
        
        locationManager = CLLocationManager()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationManager.delegate = self;
        

        // user activated automatic authorization info mode
        let status = CLLocationManager.authorizationStatus()
        if status == .notDetermined || status == .denied || status == .authorizedWhenInUse {
            // present an alert indicating location authorization required
            // and offer to take the user to Settings for the app via
            // UIApplication -openUrl: and UIApplicationOpenSettingsURLString
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
        }
        locationManager.startUpdatingLocation()
        locationManager.startUpdatingHeading()
        
        
        //mapview setup to show user location
        map.delegate = self
        map.showsUserLocation = true
        map.mapType = MKMapType(rawValue: 0)!
        map.userTrackingMode = MKUserTrackingMode(rawValue: 2)!
        
        //The selector defining the action message to send to the target object when the user taps this bar button item.
        Open.action = Selector("revealToggle:")
        //alternatively you can just use the menu item Open to access the reveal View Controller
        //The object that receives an action when the item is selected.
        Open.target = self.revealViewController()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        map.mapType = MKMapType(rawValue: 0)!
    }
    
    override func viewWillAppear(_ animated: Bool) {
        locationManager.startUpdatingHeading()
        locationManager.startUpdatingLocation()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        locationManager.stopUpdatingHeading()
        locationManager.stopUpdatingLocation()
    }
    // MARK :- CLLocationManager delegate
    func locationManager(_ manager: CLLocationManager, didUpdateToLocation newLocation: CLLocation!, fromLocation oldLocation: CLLocation) {
        
        //println("present location : \(newLocation.coordinate.latitude),\(newLocation.coordinate.longitude)")
        
        //drawing path or route covered
        let oldCoordinates = oldLocation.coordinate
        let newCoordinates = newLocation.coordinate
        
        if oldCoordinates.latitude != 0 {
            
            if (oldLocation as CLLocation?) != nil {
                var area = [oldCoordinates, newCoordinates]
                let polyLine = MKPolyline(coordinates: &area, count: area.count)
                map.add(polyLine)
            }
        }
        
        //calculation for location selection for pointing annoation
        if let previousLocationNew = previousLocation as CLLocation?{
            //case if previous location exists
            if previousLocation.distance(from: newLocation) > 200 {
               // addAnnotationsOnMap(newLocation)
                previousLocation = newLocation
            }
        }else{
            //case if previous location doesn't exists
            //addAnnotationsOnMap(newLocation)
            previousLocation = newLocation
        }
    }
    
   
    // MARK :- MKMapView delegate
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
      
        let pr = MKPolylineRenderer(overlay: overlay)
        pr.strokeColor = UIColor.green
        pr.lineWidth = 10
       
        return pr
        
        /*
        if overlay is MKPolyline {
            // return renderer for MKPolyline overlay
            return mkPolylineRenderer
        } else {
            // handle the different type of overlay...
            return otherTypeOfOverlayRenderer
        }
        */

    }
}

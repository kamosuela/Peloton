//
//  PageTwo.swift
//  Demo
//
//  Created by Kevin Izadpanah on 2/11/17.
//  Copyright © 2017 Kevin Izadpanah. All rights reserved.
//

import Foundation


class PageTwo:UIViewController{

    @IBOutlet weak var Open: UIBarButtonItem!
    

    override func viewDidLoad() {
        
        /*
         The view that the controller manages and attaches a gesture Recognizer belongs to Hello instance self.
         Inside of the gesture recognizer you are calling the method revealViewController from SWRevealViewController
         and then accessing the panGestureRecgonizer method from the SWRevealViewController using self which is the Hello
         instance/aka object reference.
         */
        
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        Open.target = self.revealViewController()
        Open.action = Selector("revealToggle:")
        
    }
    


}
